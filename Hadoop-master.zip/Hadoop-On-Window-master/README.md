# Hadoop Collection
In This repository you can learn 

* [How to install Hadoop 2.8.0 on Window 10](https://github.com/MuhammadBilalYar/HADOOP-INSTALLATION-ON-WINDOW-10/wiki/Step-by-step-Hadoop-2.8.0-installation-on-Window-10)
* [How to Run Hadoop wordcount MapReduce Example on Windows 10](https://github.com/MuhammadBilalYar/HADOOP-INSTALLATION-ON-WINDOW-10/wiki/How-to-Run-Hadoop-wordcount-MapReduce-Example-on-Windows-10)
